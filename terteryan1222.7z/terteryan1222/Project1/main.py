import math

a = 71
y = 18
j = 84
x = a-y
print(math.acos(1))

