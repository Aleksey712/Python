b = 29
a = 19
sum = a+b
print(sum)

